- Make Sure Already Login On Dashboard Your Grass Account
- Right Click > Inspect OR F12
- Search/Go/Click Application > Storage > Click Local Storage > Click https://app.getgrass.io/
- Fill Filter With userId, You Will Found Your userId Grass

[![YLAS GAMERS](https://img001.prntscr.com/file/img001/QjiSwHhQTOi7op-gHY-DJg.png)](https://github.com/ylasgamers/getgrass)
